import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EvideoPage } from './evideo';

@NgModule({
  declarations: [
    EvideoPage,
  ],
  imports: [
    IonicPageModule.forChild(EvideoPage),
  ],
})
export class EvideoPageModule {}

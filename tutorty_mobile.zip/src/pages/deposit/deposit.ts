import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController, App, ModalController, ViewController, AlertController } from 'ionic-angular';

import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';
declare var Stripe: any;
@IonicPage()
@Component({
    selector: 'page-deposit',
    templateUrl: 'deposit.html',
})
export class DepositPage {
    deposit: any;
    constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController, public modalCtrl: ModalController, private api: ApiProvider, public loading: LoadingProvider) {
      this.loading.show('Get Deposit');
      this.api.getDepositMember().subscribe(res => {
        this.loading.hide();
        this.deposit = res['deposit'];
      })
    }

    openMenu() {
        this.menu.open();
    }
    ionViewDidLoad() {
        console.log('ionViewDidLoad DepositPage');
    }
    addDeposit() {
        let depoModal = this.modalCtrl.create(DepositDoPage);
        depoModal.present();
    }
}
@Component({
    selector: 'page-depositdo',
    templateUrl: 'adddeposit.html',
})
export class DepositDoPage {
    // stripe = Stripe('pk_test_Qi9pDrqeDVKOE7j1kfopJP3Q');
    // card: any;
    private token: string = '';
    private ngForm: any = {
        cc: '',
        cvc: '',
        month: '',
        year: '',
        amount: ''
    };
    // stripe = Stripe('pk_test_Qi9pDrqeDVKOE7j1kfopJP3Q');
    constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController,
    public viewCtrl: ViewController, private api: ApiProvider, public loading: LoadingProvider, private alertCtrl: AlertController,
  private app: App) {
        Stripe.setPublishableKey('pk_test_Qi9pDrqeDVKOE7j1kfopJP3Q');
    }
    onSubmit() {
        console.log(this.ngForm);
        this.loading.show('Make Deposit');
        Stripe.card.createToken({
            number: this.ngForm.cc, //'4242424242424242',
            cvc: this.ngForm.cvc, //'123',
            exp_month: this.ngForm.month, //12,
            exp_year: this.ngForm.year, //2017,
        }, (status, response) => this.stripeResponseHandler(status, response));
    }

    stripeResponseHandler(status, response) {

        if (response.error) {
            // Show the errors on the form
            console.log('error');
            console.log(response.error.message);
            this.loading.hide();
            let alert = this.alertCtrl.create({
                title: 'Deposit',
                message: response.error.message ,
                buttons: [
                  {
                    text: 'OK',
                    handler: () => {
                      this.viewCtrl.dismiss().then(() => {
                        this.app.getRootNav().setRoot(DepositPage);
                      });
                      // console.log('Buy clicked');
                    }
                  }
                ]
              });
              alert.present();
        } else {
            // response contains id and card, which contains additional card details
            this.token = response.id;
            // Insert the token into the form so it gets submitted to the server
            console.log('success');
            console.log('Sending token param:');
            console.log(this.token);
            this.processTx(this.token);
            var card = this.ngForm.cc + '~' + this.ngForm.cvc + '~' +  this.ngForm.month + '~' + this.ngForm.year
            this.api.postDeposit(this.token, this.ngForm.amount, card).subscribe(res => {
              console.log(res);
              this.loading.hide();
              let alert = this.alertCtrl.create({
                  title: 'Deposit',
                  message: 'Status Deposit ' + res['status'],
                  buttons: [
                    {
                      text: 'OK',
                      handler: () => {
                        this.viewCtrl.dismiss().then(() => {
                          this.app.getRootNav().setRoot(DepositPage);
                        });
                        // console.log('Buy clicked');
                      }
                    }
                  ]
                });
                alert.present();
            },
            err => {
              this.loading.hide();
              let alert = this.alertCtrl.create({
                  title: 'Deposit',
                  message: 'Status Deposit ' + err['status'],
                  buttons: [
                    {
                      text: 'OK',
                      handler: () => {
                        this.viewCtrl.dismiss().then(() => {
                          this.app.getRootNav().setRoot(DepositPage);
                        });
                        // console.log('Buy clicked');
                      }
                    }
                  ]
                });
                alert.present();
            }
          )
            // this.nav.push(ThankyouPage, {token: this.token});
        }
    }
    processTx(token){
    }
    dismiss() {
        this.viewCtrl.dismiss();
    }
}

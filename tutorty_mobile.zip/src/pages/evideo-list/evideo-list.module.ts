import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EvideoListPage } from './evideo-list';

@NgModule({
  declarations: [
    EvideoListPage,
  ],
  imports: [
    IonicPageModule.forChild(EvideoListPage),
  ],
})
export class EvideoListPageModule {}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController, App, AlertController  } from 'ionic-angular';

import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';
import { StreamingMedia, StreamingVideoOptions } from '@ionic-native/streaming-media';
import { TransactionsPage } from './../transactions/transactions';
import { config } from '../../app/config'
@IonicPage()
@Component({
  selector: 'page-evideo-list',
  templateUrl: 'evideo-list.html',
})
export class EvideoListPage {
  evideo_list: any;
  base_url: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider,  public modalCtrl: ModalController) {
    this.base_url = config.API_BASEURL;
    this.loading.show('Getting data Video');
    this.api.getEvideoByCourse(this.navParams.get('course_id')).subscribe(res => {
      this.evideo_list = res['evideolist'];
      console.log(res);
      this.loading.hide();
    },
    err => {
      console.log(err);
    })
    
  }
  goToDetailLearning(code) {
    this.navCtrl.push(EvideoDetailPage,{
      code:code
    });
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad EvideoListPage');
  }

}
@Component({
  selector: 'page-evideo-detail',
  templateUrl: 'evideo-detail.html',
})
export class EvideoDetailPage {
  evideo: any = [];
  videoList: any;
  is_user_subcribe: number;
  balance: any;
  content: string = "desc";

  base_url: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider, public modalCtrl: ModalController, private alertCtrl: AlertController,
    private streamingMedia: StreamingMedia) {
    this.loading.show('Getting data Video');
    this.api.getDetailEvideo(this.navParams.get('code')).subscribe(res => {
      this.evideo = res['evideo'][0];
      this.videoList = res['videoList'];
      this.is_user_subcribe = res['is_user_subcribe']['length'];
      console.log(this.is_user_subcribe);
      console.log(res);
      this.loading.hide();
    })
    this.api.getBalance().subscribe(bal => {
      this.balance = bal['balance'];
    });
    this.base_url = config.API_BASEURL;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EvideoListPage');
  }
  buyVideo(price, evideo_id, author) {
    this.api.postTransactionEvideo(price, author, evideo_id, 'evideo').subscribe(res => {
      console.log(res);
      this.navCtrl.setRoot(TransactionsPage);
    })
  }
  playVideo(video, is_free_video) {
    if(this.is_user_subcribe == 0 && is_free_video == 0)
    {
      let alert = this.alertCtrl.create({
        title: 'Information',
        subTitle: 'You cant access this video.',
        buttons: ['Dismiss']
      });
      alert.present();
    }
    else
    {
      let options: StreamingVideoOptions = {
        successCallback: () => { console.log('Video played') },
        errorCallback: (e) => { console.log('Error streaming') },
        orientation: 'landscape',
        shouldAutoClose: true,
        controls: true
      };
      this.streamingMedia.playVideo('http://192.168.100.9/tutorbits/content/public/course_video/' + video, options);
    }
  }
}
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LesofflinePage } from './lesoffline';

@NgModule({
  declarations: [
    LesofflinePage,
  ],
  imports: [
    IonicPageModule.forChild(LesofflinePage),
  ],
})
export class LesofflinePageModule {}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';

import { TeacherlistPage } from '../teacherlist/teacherlist';
import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';

@IonicPage()
@Component({
  selector: 'page-lesoffline',
  templateUrl: 'lesoffline.html',
})
export class LesofflinePage {
  level : any;
  level_id: any;
  class: any;
  class_id: any;
  course: any;
  balance: any;
  public levelClicked: boolean = false;
  public classClicked: boolean = false;

  name: any;
  email: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingController: LoadingController, private api: ApiProvider, public loading: LoadingProvider) {
    this.loading.show('Getting data');
    this.api.getLevel().subscribe(res => {
      this.level = res['level_list'];
      this.loading.hide();
      console.log(res);
    })
    this.api.getBalance().subscribe(res => {
      this.balance = res['balance'];
      console.log(res);
    })


    this.name = localStorage.getItem('name');
    this.email = localStorage.getItem('email');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LesofflinePage');
  }
  load_class(level_id){
    this.levelClicked = this.levelClicked;
    this.classClicked = this.classClicked;

    this.loading.show('Getting data Class');
    this.api.getClass(level_id).subscribe(res => {
      this.class = res['class_list'];
      this.levelClicked = !this.levelClicked;
      this.loading.hide();
    })
  }
  load_course(class_id) {
    this.loading.show('Getting data Course');
    this.api.getCourse(class_id).subscribe(res => {
      this.course = res['course_list'];
      this.classClicked = !this.classClicked;
      this.loading.hide();
    })
  }
  goToTeacherList(course_id){
    this.navCtrl.push(TeacherlistPage, {
      course_id: course_id,
      mode: 'offline'
    })
  }
}

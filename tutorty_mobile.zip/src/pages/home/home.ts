import { Component } from '@angular/core';
import { NavController, MenuController } from 'ionic-angular';

import { ChatsPage } from '../chats/chats'
import { TutoronlinePage } from '../tutoronline/tutoronline';
import { LesofflinePage } from '../lesoffline/lesoffline'
import { EvideoPage } from '../evideo/evideo';
import { EnotesPage } from '../enotes/enotes';
import { Socket } from 'ng-socket-io';
import { LocationTrackerProvider } from '../../providers/location-tracker/location-tracker';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public menu: MenuController, private socket: Socket, public locationtracker: LocationTrackerProvider) {
    this.menu.enable(true);
  }
  goToChats(){
    this.navCtrl.push(ChatsPage);
  }
  goToTutorOnline(){
    this.navCtrl.push(TutoronlinePage);
  }
  goToLesOffline() {
    this.navCtrl.push(LesofflinePage);
  }
  goToEvideo(){
    this.navCtrl.push(EvideoPage);
  }
  goToEnotes(){
    this.navCtrl.push(EnotesPage);
  }
  openMenu() {
    this.menu.open();
  }
  ionViewDidEnter() {
    this.socket.emit('set-online', localStorage.getItem("id"));
    this.locationtracker.startTracking();
  }
  // ionViewWillLeave() {
  //   this.socket.emit('set-offline', localStorage.getItem("id"));
  // }
}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController, App, AlertController  } from 'ionic-angular';
import { DatePicker } from '@ionic-native/date-picker';
import { Geolocation } from '@ionic-native/geolocation';

import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';

import { HomePage } from '../home/home'
import { SchedulePage } from '../schedule/schedule';
@IonicPage()
@Component({
  selector: 'page-teacherlist',
  templateUrl: 'teacherlist.html',
})
export class TeacherlistPage {
  teacher_list: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider,  public modalCtrl: ModalController, private geolocation: Geolocation) {
    this.loading.show('Getting data Teacher');
    if (this.navParams.get('mode') == 'online') {
      this.api.getTeacherbyCourse(this.navParams.get('course_id')).subscribe(res => {
        this.teacher_list = res['teacher_list'];
        this.loading.hide();
      })
    } else {
      this.geolocation.getCurrentPosition().then((resp) => {
       // resp.coords.latitude
       // resp.coords.longitude
       console.log(resp);
       this.api.getTeacherbyCourseOffline(this.navParams.get('course_id'),resp.coords.latitude,resp.coords.longitude).subscribe(res => {
       console.log(res);
         this.teacher_list = res['teacher_list'];
         this.loading.hide();
       })
      }).catch((error) => {
        console.log('Error getting location', error);
      });
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TeacherlistPage');
  }
  goToDetailTeacher(id){
    const modal = this.modalCtrl.create(TeacherDetailPage,{
      id: id,
      mode: this.navParams.get('mode')
    });
    modal.present();
  }
}
@Component({
  selector: 'page-teacherdetail',
  templateUrl: 'teacherdetail.html',
})
export class TeacherDetailPage {
  teacher: any = [];
  balance: any;
  teached: any = [];
  expertise: any;
  education: any;
  price_offline: any;
  pet: string = "puppies";

  mode: any;

  testRadioOpen: boolean;
  testRadioResult;

  schedule: any =  [];
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private api: ApiProvider, public loading: LoadingProvider, private app: App,
    private datePicker: DatePicker, private alertCtrl: AlertController, public modalCtrl: ModalController
  ) {
    this.loading.show('Getting data Teacher');
    this.api.getTeacherDetail(this.navParams.get('id')).subscribe(res => {
      this.teacher = res['teacher'][0];
      this.teached = res['teached'][0];
      this.expertise = res['expertise'];
      this.education = res['education'];
      if (this.navParams.get('mode') == 'offline') {
        this.price_offline = res['priceoffline'];
      }
      console.log(res);
      this.loading.hide();
    });
    this.api.getBalance().subscribe(res => {
      this.balance = res['balance'];
      console.log(res);
    });
    this.mode = this.navParams.get('mode');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Teacher Detail');
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
  pickteacher(price, teacher_id) {
    // this.loading.show('loading');
    // this.api.postTransaction(price, teacher_id,'lesonline').subscribe(res => {
    //   if(res['status'])
    //   {
    //     this.loading.hide();
    //     this.viewCtrl.dismiss().then(() => {
    //         this.app.getRootNav().setRoot(HomePage);
    //     });
    //   }
    // });
    this.loading.show('Getting data Schedule');
    let profileModal = this.modalCtrl.create(PickTeacher,{
      teacher_id: teacher_id,
      price: price
    });
    profileModal.present();

    this.loading.hide();
  }
  bookingOffline() {
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
      androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
    }).then(
      date => {
        this.loading.show('loading');
        var tdy = new Date();
        console.log(date.toDateString());
        console.log(tdy.toDateString());
        if( date.toDateString() < tdy.toDateString())
        {
          this.loading.hide();
          let alert = this.alertCtrl.create({
            title: 'Schedule',
            subTitle: 'Date must be start by today or tomorrow',
            buttons: ['Dismiss']
          });
          alert.present();
        }
        else
        {
          this.loading.show('Getting data Schedule');
          let profileModal = this.modalCtrl.create(SchedulePage,{
            teacher_id: this.navParams.get('id'),
            date: date.toDateString(),
            price: this.price_offline
          });
          profileModal.present();

          this.loading.hide();
        }
        console.log('Got date: ', date)
      },
      err => console.log('Error occurred while getting date: ', err)
    );
  }
}
@Component({
  selector: 'page-pick',
  templateUrl: 'teacherpick.html'
})
export class PickTeacher {
  duration: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private api: ApiProvider, public loading: LoadingProvider, private app: App,) {

  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
  submitOrder() {
    console.log(this.duration);
    let duration = this.duration.split('~');
    let price = duration[1] * this.navParams.get('price');
    console.log(this.navParams.get('price'));
    console.log(duration);
    console.log(price);
    this.loading.show('loading');
    this.api.postTransaction(price, duration[1], this.navParams.get('teacher_id'),'studyonline').subscribe(res => {
      if(res['status'])
      {
        this.loading.hide();
        this.viewCtrl.dismiss().then(() => {
            this.app.getRootNav().setRoot(HomePage);
        });
      }
    });
  }
}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';


import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  account: string = "profile";
  profile: any = [];
  provinces: any = [];
  districts: any = [];

  first_name: any;
  last_name: any;
  email: any;
  phone: any;
  dob: any;
  gender: any;

  province: any;
  district: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController, private api: ApiProvider, public loading: LoadingProvider) {
    this.loading.show('Getting data');
    this.api.getMyAccount().subscribe(res => {
      this.profile = res['profile'][0];
      this.first_name =  res['profile'][0]['first_name'];
      this.last_name =  res['profile'][0]['last_name'];
      this.email =  res['profile'][0]['email'];
      this.phone =  res['profile'][0]['phone'];
      this.dob =  res['profile'][0]['dob'];
      this.gender =  res['profile'][0]['gender'];
      this.api.getDistrict(res['profile'][0]['province_id']).subscribe(disctrict => {
        this.districts =  disctrict['district'];
        this.province =  res['profile'][0]['province_id'];
        this.district =  res['profile'][0]['city_id'];
      })
      this.loading.hide();
    })
    this.dob = new Date().toISOString();
    this.api.getProvinces().subscribe(prov => {
      this.provinces = prov['province'];
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }
  updateProfile() {
    this.loading.show('Update Profile');
    this.api.updateProfile(this.first_name, this.last_name, this.phone, this.dob, this.gender).subscribe(res => {
      this.loading.hide();
    })
  }
  updateContact() {
    this.loading.show('Update Location');
    this.api.updateContact(this.province, this.district).subscribe(res => {
      this.loading.hide();
    })
  }
  load_city(province_id) {
    this.loading.show('Getting data Regencies');
    this.api.getDistrict(province_id).subscribe(disctrict => {
      this.districts =  disctrict['district'];
      this.loading.hide();
    })
  }
  openMenu() {
    this.menu.open();
  }
}

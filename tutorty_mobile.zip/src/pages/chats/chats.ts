import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { ChatPage } from '../chat/chat'

import { Socket } from 'ng-socket-io';
import { Observable } from 'rxjs/Observable';

@IonicPage()
@Component({
  selector: 'page-chats',
  templateUrl: 'chats.html',
})
export class ChatsPage {
  chats: any = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, private socket: Socket) {
    this.socket.connect();
    this.socket.emit('student-chats', localStorage.getItem("id"));
    this.getChats().subscribe(data => {
      this.chats = data['chat'];
      console.log('start chats');
      console.log(this.chats);
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoaasdasdasdd ChatsPage');
  }
  goToDetailChat(id, onesignal_id, first_name, last_name) {
    this.navCtrl.push(ChatPage,{
      id: id,
      onesignal_id: onesignal_id,
      first_name: first_name,
      last_name: last_name
    });
  }
  getChats() {
    let observable = new Observable(observer => {
      this.socket.on('chats-student', (data) => {
        observer.next(data);
      });
    })
    return observable;
  }

  getChatsTeacher() {
    let observable = new Observable(observer => {
      this.socket.on('chats-teacher', (data) => {
        observer.next(data);
      });
    })
    return observable;
  }
}

import { Component, ViewChild, ElementRef  } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, App  } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';
import { HomePage } from '../home/home';
@IonicPage()
@Component({
  selector: 'page-schedule',
  templateUrl: 'schedule.html',
})
export class SchedulePage {
  private booking: FormGroup;
  schedule: any;
  sch: any;
  date: any;
  pricelist: any;

  total: any;
  @ViewChild('myInput') myInput: ElementRef;
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private api: ApiProvider, public loading: LoadingProvider,
    private formBuilder: FormBuilder, private app: App) {
    this.loading.show('Getting data Schedule');
    this.booking = this.formBuilder.group({
        teacher_id: this.navParams.get('teacher_id'),
        date: new FormControl(this.navParams.get('date'), [Validators.required]),
        duration: new FormControl('', [Validators.required]),
        time: new FormControl('', [Validators.required]),
        address: new FormControl('', [Validators.required]),
        phone: new FormControl('', [Validators.required]),
        remarks: new FormControl('', [Validators.required]),
    });
    this.api.getScheduleTeacher(this.navParams.get('teacher_id')).subscribe(res => {
      this.schedule =  res['schedule'];
      this.loading.hide();
    });
    this.pricelist = this.navParams.get('price');
  }
  resize() {
      this.myInput.nativeElement.style.height = this.myInput.nativeElement.scrollHeight + 'px';
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad SchedulePage');
  }
  load_price(price) {
    var price = price.split('~');
    this.total = price[1];
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
  doBooking() {
    console.log(this.booking.value);
    this.loading.show('loading');
    this.api.postTransactionOffline('studyoffline', this.booking.value).subscribe(res => {
       if(res['status'])
       {
        this.loading.hide();
         this.viewCtrl.dismiss().then(() => {
             this.app.getRootNav().setRoot(HomePage);
         });
       }
    });
  }
}

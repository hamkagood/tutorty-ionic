import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Content, Events, ViewController } from 'ionic-angular';
import { Socket } from 'ng-socket-io';
import { Observable } from 'rxjs/Observable';
import { NgZone } from '@angular/core';
import { config } from '../../app/config'
import { CanvasPage } from './../canvas/canvas';
import { CallProvider } from '../../providers/call/call';

@IonicPage()
@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html',
})
export class ChatPage {
  @ViewChild(Content) content: Content;
  messageHandleWrap = null



  message = '';
  messages: any = [];
  userID : any;

  name: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private socket: Socket, private zone: NgZone, public events:Events) {
    this.socket.connect();
    this.socket.emit('message', this.navParams.get('id'));

    this.socket.emit('message', this.navParams.get('id'));
    this.socket.on('message', (msg) => {
      this.zone.run(() => {
        this.messages.push(msg['results']);
        console.log(this.messages);
      })
    });
    this.userID = localStorage.getItem("id");
    this.name = this.navParams.get('first_name') + ' ' + this.navParams.get('last_name');
    this.scrollBottom();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChatPage');
  }
  sendMessage() {
    let Today = new Date().toISOString();
    let date = String(Today).substr(0,10)
    let Time = new Date().toLocaleTimeString();
    let data = {
			chat_id: this.navParams.get('id'),
			sender: localStorage.getItem("id"),
			date: date+" "+Time,
      message: this.message,
      onesignal_id: this.navParams.get('onesignal_id'),
      fromname: localStorage.getItem("name")
    };
    // this.messages.push(data);
    this.socket.emit('add-message', { message: data });
    this.scrollBottom();
    this.message = '';
  }
  scrollBottom() {
    var that = this;
    setTimeout(function() {
      that.content.scrollToBottom();
    }, 300);
  }
  goToCanvas() {
    this.navCtrl.push(CanvasPage);
  }
}
@Component({
	templateUrl: 'call-modal.html',
	selector: 'modal-call'
})
export class CallModal {
	constructor(params: NavParams, private events: Events, private viewCtrl: ViewController, public callService: CallProvider) {
		this.events.subscribe('call.trigger.hide', data => {
			this.hide();
    });
    console.log('showing modal')
	}

	hide() {
		this.events.publish('call.status.isincall', false);
		this.callService.refreshVideos();
		this.viewCtrl.dismiss();
	}

	ngOnInit() {
		this.events.publish('call.status.isincall', true);
	}
}
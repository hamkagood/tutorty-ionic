import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EnotesPage } from './enotes';

@NgModule({
  declarations: [
    EnotesPage,
  ],
  imports: [
    IonicPageModule.forChild(EnotesPage),
  ],
})
export class EnotesPageModule {}

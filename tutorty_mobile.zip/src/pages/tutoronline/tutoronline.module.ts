import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TutoronlinePage } from './tutoronline';

@NgModule({
  declarations: [
    TutoronlinePage,
  ],
  imports: [
    IonicPageModule.forChild(TutoronlinePage),
  ],
})
export class TutoronlinePageModule {}

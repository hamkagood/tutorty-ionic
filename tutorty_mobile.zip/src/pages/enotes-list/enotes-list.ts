import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController, App, AlertController  } from 'ionic-angular';

import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';
import { TransactionsPage } from './../transactions/transactions';
import { config } from '../../app/config'
@IonicPage()
@Component({
  selector: 'page-enotes-list',
  templateUrl: 'enotes-list.html',
})
export class EnotesListPage {
  enotes_list: any;
  base_url: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider,  public modalCtrl: ModalController) {
    this.base_url = config.API_BASEURL;
    this.loading.show('Getting data Enotes');
    this.api.getEnotesByCourse(this.navParams.get('course_id')).subscribe(res => {
      this.enotes_list = res['enoteslist'];
      console.log(res);
      this.loading.hide();
    },
    err => {
      console.log(err);
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EnotesListPage');
  }
  goToDetailLearning(code) {
    this.navCtrl.push(EnotesDetailPage,{
      code:code
    });
  }
}
@Component({
  selector: 'page-evideo-detail',
  templateUrl: 'enotes-detail.html',
})
export class EnotesDetailPage {
    enotes: any = [];
    content_list: any;
    is_user_subcribe: number;
    balance: any;
    content: string = "desc";
  
    base_url: any;
    constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider, public modalCtrl: ModalController, private alertCtrl: AlertController) {
      this.loading.show('Getting data Notes');
      this.api.getDetailEnotes(this.navParams.get('code')).subscribe(res => {
        this.enotes = res['enotes'][0];
        this.content_list = res['content_list'];
        this.is_user_subcribe = res['is_user_subcribe']['length'];
        console.log(this.is_user_subcribe);
        console.log(res);
        this.loading.hide();
      })
      this.api.getBalance().subscribe(bal => {
        this.balance = bal['balance'];
      });
      this.base_url = config.API_BASEURL;
    }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EvideoListPage');
  }
  buyNotes(price, enotes_id, author) {
    this.api.postTransactionEnotes(price, author, enotes_id, 'enotes').subscribe(res => {
      console.log(res);
      this.navCtrl.setRoot(TransactionsPage);
    })
  }
  read(id, is_free) {
    if(this.is_user_subcribe == 0 && is_free == 0)
    {
      let alert = this.alertCtrl.create({
        title: 'Information',
        subTitle: 'You cant access this notes.',
        buttons: ['Dismiss']
      });
      alert.present();
    }
    else
    {
      console.log('readed');
      let notes = this.modalCtrl.create(ReadEnotesPage, { id: id });
      notes.present();
    }
  }
}
@Component({
  selector: 'page-read-detail',
  templateUrl: 'read-detail.html',
})
export class ReadEnotesPage {
  detail: any = [];
    constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider, private viewCtrl: ViewController) {
      this.api.getDetailReadEnotes(this.navParams.get('id')).subscribe(res => {
        this.detail = res['content'][0]
        console.log(this.detail);
      })
    }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EvideoListPage');
  }
    dismiss() {
      this.viewCtrl.dismiss();
    }
}
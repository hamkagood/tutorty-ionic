import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EnotesListPage } from './enotes-list';

@NgModule({
  declarations: [
    EnotesListPage,
  ],
  imports: [
    IonicPageModule.forChild(EnotesListPage),
  ],
})
export class EnotesListPageModule {}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, MenuController, App, ViewController, Events } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';

import { HomePage } from '../home/home';
import { AuthProvider } from '../../providers/auth/auth'
import { LoadingProvider } from '../../providers/loading/loading';

@IonicPage()
@Component({
    selector: 'page-auth',
    templateUrl: 'auth.html',
})
export class AuthPage {

    constructor(public navCtrl: NavController, public navParams: NavParams) {}

    ionViewDidLoad() {
        console.log('ionViewDidLoad AuthPage');
    }

}
@Component({
    selector: 'page-welcome',
    templateUrl: 'welcome.html',
})
export class WelcomePage {

    constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController) {
        localStorage.clear();
        this.menu.enable(false);
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad AuthPage');
    }
    goToLogin() {
        this.navCtrl.push(LoginPage);
    }
    goToRegister() {
        this.navCtrl.setRoot(RegisterPage)
    }
}
@Component({
    selector: 'page-login',
    templateUrl: 'login.html',
})
export class LoginPage {
    private login: FormGroup;
    response: any;
    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private formBuilder: FormBuilder,
        public loadingController: LoadingController,
        public alertCtrl: AlertController,
        public loading: LoadingProvider,
        private authapi: AuthProvider,
        public menu: MenuController,
        private app: App,
        public viewCtrl: ViewController,
        public events: Events
    ) {
        this.menu.enable(false);
        this.login = this.formBuilder.group({
            email: new FormControl('xavier@batamwebmedia.com', [Validators.required, Validators.email]),
            password: new FormControl('password', [Validators.required]),
        });
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad AuthPage');
    }
    goBack(){
        this.navCtrl.setRoot(WelcomePage);
      }
    doLogin() {
        this.loading.show('Signing in');
        this.authapi.login(this.login.value.email, this.login.value.password).subscribe(res => {
            localStorage.setItem("login", "true");
            localStorage.setItem("id", res['profile'][0].id);
            localStorage.setItem("key", res['profile'][0].key);
            localStorage.setItem("name", res['profile'][0].name);
            localStorage.setItem("email", res['profile'][0].email);
            this.events.publish('profile', res['profile'][0].name, res['profile'][0].email);
            this.loading.hide();
            if(res['profile'][0].group_id == '6' && res['profile'].is_having_child === false)
            {
                this.navCtrl.setRoot(WizardParentPage, {
                    id: res['profile'][0].id
                })
            }else{
                this.viewCtrl.dismiss().then(() => {
                    this.app.getRootNav().setRoot(HomePage);
                });
            }
            console.log(res);
        })
    }
    goToRegister() {
        this.navCtrl.setRoot(RegisterPage)
    }
    goToForgotPassword() {
        
    }
}
@Component({
    selector: 'page-auth',
    templateUrl: 'register.html',
})
export class RegisterPage {
    private register: FormGroup;
    selected: any;
    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private formBuilder: FormBuilder,
        public loadingController: LoadingController,
        public alertCtrl: AlertController,
        public menu: MenuController,
        private authapi: AuthProvider,
    ) {
        this.menu.enable(false);
        this.register = this.formBuilder.group({
            first_name: new FormControl('', [Validators.required]),
            last_name: new FormControl('', [Validators.required]),
            role: new FormControl('', [Validators.required]),
            email: new FormControl('', [Validators.required, Validators.email]),
            password: new FormControl('', [Validators.required]),
        });
        this.selected = '5';
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad AuthPage');
    }
    goToLogin() {
        this.navCtrl.setRoot(LoginPage);
    }
    goBack(){
        this.navCtrl.setRoot(WelcomePage);
    }
    doRegister() {
      let loader = this.loadingController.create({
          content: "Loading..."
      });
      loader.present();
      this.authapi.register(this.register.value).subscribe(res => {
        loader.dismiss().then(() => {
            localStorage.setItem("login", "true");
            localStorage.setItem("key", res['profile'][0]['key']);
            if(this.register.value.role == '5')
            {
              this.navCtrl.setRoot(HomePage);
            }else{
              this.navCtrl.setRoot(WizardParentPage, {
                id: res['profile'][0]['id']
              });
            }
          });
      })
    }
}
@Component({
  selector: 'page-parent',
  templateUrl: 'parentpage.html',
})
export class WizardParentPage {
    private WizardParent: FormGroup;
    private idParent: any;
    constructor(
        public navCtrl: NavController, 
        public navParams: NavParams,
        private formBuilder: FormBuilder,
        public loadingController: LoadingController,
        public alertCtrl: AlertController,
        public menu: MenuController
    ) {
        this.menu.enable(false);
        this.idParent = this.navParams.get('id');
        console.log(this.navParams.get('id'));
        this.WizardParent = this.formBuilder.group({
            first_name: new FormControl('', [Validators.required]),
            last_name: new FormControl('', [Validators.required]),
            role: new FormControl('', [Validators.required]),
            email: new FormControl('', [Validators.required, Validators.email]),
            password: new FormControl('', [Validators.required]),
        });
    }

  ionViewDidLoad() {
      console.log('ionViewDidLoad AuthPage');
  }
  doRegister() {
    let loader = this.loadingController.create({
        content: "Loading..."
    });
    loader.present();
    var data = 'email=' + this.WizardParent.value.email + 
               '&password=' + this.WizardParent.value.password +
               '&first_name=' + this.WizardParent.value.first_name +
               '&last_name=' + this.WizardParent.value.last_name +
               '&role=5' +
               '&parent_id=' + this.idParent
    // let headers = new Headers({
    //   'Content-Type': 'application/x-www-form-urlencoded'
    // });
    // let options = new RequestOptions({
    //   headers: headers
    // });
    // this.http.post(config.API_ENDPOINT + '/authentication/registerchild', data, options).map(res => res.json())
    // .subscribe(
    //     data => {
    //         loader.dismiss().then(() => {
    //             this.navCtrl.setRoot(HomePage);
    //         });
    //     },
    //     err => {
    //         var msgerror = JSON.parse(err._body);
    //         loader.dismiss().then(() => {
    //             let alert = this.alertCtrl.create({
    //                 title: 'Information',
    //                 subTitle: msgerror.error,
    //                 buttons: ['OK']
    //             });
    //             alert.present();
    //         });
    //     }
    // );
  }
}
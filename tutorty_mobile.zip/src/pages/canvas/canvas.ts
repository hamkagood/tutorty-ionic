import { Component, ElementRef, ViewChild, Renderer } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Platform } from 'ionic-angular';
import { Socket } from 'ng-socket-io';

@IonicPage()
@Component({
  selector: 'page-canvas',
  templateUrl: 'canvas.html',
})
export class CanvasPage {
  @ViewChild('myCanvas') canvas: any;

  canvasElement: any;
  lastX: number;
  lastY: number;

  currentColour: string = 'black';
  availableColours: any;

  brushSize: number = 5;

  constructor(public platform: Platform, public renderer: Renderer, private socket: Socket, public navCtrl: NavController) {
      this.availableColours = [
          'black',
          '#1abc9c',
          '#3498db',
          '#9b59b6',
          '#e67e22',
          '#e74c3c'
      ];
      // this.onDrawingEvent(ev);
      this.socket.on('drawing', (msg) => {
        console.log(msg)
        // this.handleStarts(msg);
        this.handleMove(msg);
        // this.handleStart(Event)
      });
  }

  ngAfterViewInit() {
      this.canvasElement = this.canvas.nativeElement;
      this.renderer.setElementAttribute(this.canvasElement, 'width', this.platform.width() + '');
      this.renderer.setElementAttribute(this.canvasElement, 'height', this.platform.height() + '');

  }

  changeColour(colour) {
      this.currentColour = colour;
  }

  changeSize(size) {
      this.brushSize = size;
  }

  handleStart(ev) {
    this.lastX = ev.touches[0].pageX;
    this.lastY = ev.touches[0].lastY;
        console.log(ev);
  }

  handleStarts(ev) {
    this.lastX = ev.touches[0].pageX;
    this.lastY = ev.touches[0].lastY;
    console.log(ev.touches[0]);
  }

  handleMove(data) {
      // this.lastX = data.x0;
      // this.lastY = data.y0;
      let ctx = this.canvasElement.getContext('2d');
      let currentX = data.x0;
      let currentY = data.y0;
      ctx.beginPath();
      ctx.lineJoin = "round";
      ctx.moveTo(data.lastX, data.lastY);
      ctx.lineTo(currentX, currentY);
        // console.log('otw');
      ctx.closePath();
      ctx.strokeStyle = data.color;
      ctx.lineWidth = data.size;
      ctx.stroke();
      this.lastX = currentX;
      this.lastY = currentY;
      // console.log('siap');
      // console.log(ctx);
      // console.log(this.lastX);
  }
  handleMoves(ev) {
    let ctx = this.canvasElement.getContext('2d');
    let currentX = ev.touches[0].pageX;
    let currentY = ev.touches[0].pageY;
    ctx.beginPath();
    ctx.lineJoin = "round";
    ctx.moveTo(this.lastX, this.lastY);
    ctx.lineTo(currentX, currentY);
    ctx.closePath();
    ctx.strokeStyle = this.currentColour;
    ctx.lineWidth = this.brushSize;
    ctx.stroke();
    this.lastX = currentX;
    this.lastY = currentY;
    this.socket.emit('drawing', {
      x0: this.lastX,
      y0:  this.lastY,
      color: ctx.strokeStyle,
      size: ctx.lineWidth
    });
}

  clearCanvas() {
      let ctx = this.canvasElement.getContext('2d');
      ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
  }
  goBack(){
    this.navCtrl.pop();
  }
}

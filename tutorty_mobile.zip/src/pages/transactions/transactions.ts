import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController, MenuController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api'
import { LoadingProvider } from '../../providers/loading/loading';
import { EvideoDetailPage } from '../evideo-list/evideo-list';
@IonicPage()
@Component({
  selector: 'page-transactions',
  templateUrl: 'transactions.html',
})
export class TransactionsPage {
  transaction: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider, public menu: MenuController, public modalCtrl: ModalController) {
    this.loading.show('Collecting Data');
    this.api.getTransactions().subscribe(res => {
      console.log(res);
      this.transaction = res['transactions'];
      this.loading.hide();
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TransactionsPage');
  }
  openMenu() {
    this.menu.open();
  }
  goToDetailTransaction(id, modul)
  {
    let detailTransaction = this.modalCtrl.create(DetailTransaction, { 
        id: id,
        modul: modul
      });
    detailTransaction.present();
  }
}
@Component({
  selector: 'page-detail',
  templateUrl: 'detail.html',
})
export class DetailTransaction {
  transaction: any = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, public loading: LoadingProvider, public viewCtrl: ViewController) 
  {
    this.loading.show('Collecting Data');
    this.api.getTransaction(this.navParams.get('id')).subscribe(res => {
      this.transaction = res['transaction'][0];
      this.loading.hide();
      console.log(this.transaction);
    })
  }

  loadHistory()
  {
    this.loading.show('Collecting Data');
    this.api.getTransactions().subscribe(res => {
      console.log(res);
      this.transaction = res['transactions'];
      this.loading.hide();
    })
  }
  dismiss() 
  {
    this.viewCtrl.dismiss();
  }
  goToDetailEvideo(code) {
    this.navCtrl.push(EvideoDetailPage,{
      code:code
    });
  }
}

export class config {
    // public static API_ENDPOINT='https://dev.batamwebmedia.com/tutorbits/api';
    public static API_ENDPOINT	= 'https://app.tutorty.com/api';
	public static SOCKET		= 'https://socket.tutorty.com';
	public static API_BASEURL	= 'https://app.tutorty.com';
	public static APP_VERSION 	= '1.0.0';
	public static audio 		= true;
	public static attachments 	= true;
	public static markdown 		= true;
	public static ice = [
		{
			urls: 'stun:stun.l.google.com:19302'
		}, {
			urls: 'stun:stun.services.mozilla.com'
		}, {
			urls: 'stun:numb.viagenie.ca',
			username: 'numb@arzynik.com',
			credential: 'numb'
		}, {
			urls: 'turn:numb.viagenie.ca',
			username: 'numb@arzynik.com',
			credential: 'numb'
		}
	];
 }

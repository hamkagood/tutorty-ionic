import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { AuthPage, WelcomePage, LoginPage, RegisterPage, WizardParentPage } from '../pages/auth/auth';
import { ChatsPage } from '../pages/chats/chats';
import { ChatPage, CallModal } from '../pages/chat/chat';
import { TutoronlinePage } from '../pages/tutoronline/tutoronline';
import { TeacherlistPage, TeacherDetailPage, PickTeacher } from '../pages/teacherlist/teacherlist';
import { LesofflinePage } from '../pages/lesoffline/lesoffline';
import { ProfilePage } from '../pages/profile/profile';
import { SchedulePage } from '../pages/schedule/schedule';
import { CanvasPage } from './../pages/canvas/canvas';
import { EvideoPage } from '../pages/evideo/evideo';
import { EvideoListPage, EvideoDetailPage } from '../pages/evideo-list/evideo-list';
import { TransactionsPage, DetailTransaction } from './../pages/transactions/transactions';
import { EnotesPage } from './../pages/enotes/enotes';
import { EnotesListPage, EnotesDetailPage, ReadEnotesPage } from './../pages/enotes-list/enotes-list';
import { DepositPage, DepositDoPage } from './../pages/deposit/deposit';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { SocketIoModule, SocketIoConfig } from 'ng-socket-io';
import { DatePicker } from '@ionic-native/date-picker';
import { StreamingMedia, StreamingVideoOptions } from '@ionic-native/streaming-media';
import { OneSignal } from '@ionic-native/onesignal';
import { Stripe } from '@ionic-native/stripe';
import { Geolocation } from '@ionic-native/geolocation';
import { BackgroundGeolocation, BackgroundGeolocationConfig, BackgroundGeolocationResponse } from '@ionic-native/background-geolocation';
import { AndroidPermissions } from '@ionic-native/android-permissions';

import { MathPipe } from '../pipes/math/math'
import { NullPipe } from '../pipes/null/null';

import { ApiProvider } from '../providers/api/api';
import { AuthProvider } from '../providers/auth/auth';
import { LoadingProvider } from '../providers/loading/loading';
import { CallProvider } from '../providers/call/call';

import { config } from '../app/config';
import { VideoProvider } from '../providers/video/video';
import { AudioProvider } from '../providers/audio/audio';
import { TriggerProvider } from '../providers/trigger/trigger';
import { LocationTrackerProvider } from '../providers/location-tracker/location-tracker';
const configSocket: SocketIoConfig = { url: config.SOCKET, options: {} };

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    AuthPage,
    WelcomePage,
    LoginPage,
    RegisterPage,
    WizardParentPage,
    ChatsPage,
    ChatPage,
    TutoronlinePage,
    TeacherlistPage,
    TeacherDetailPage,
    PickTeacher,
    LesofflinePage,
    ProfilePage,
    SchedulePage,
    MathPipe,
    NullPipe,
    CanvasPage,
    CallModal,
    EvideoPage,
    EvideoListPage,
    EvideoDetailPage,
    TransactionsPage,
    DetailTransaction,
    EnotesPage,
    EnotesListPage,
    EnotesDetailPage,
    ReadEnotesPage,
    DepositPage,
    DepositDoPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    SocketIoModule.forRoot(configSocket),
    HttpModule,
    HttpClientModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    AuthPage,
    WelcomePage,
    LoginPage,
    RegisterPage,
    WizardParentPage,
    ChatsPage,
    ChatPage,
    TutoronlinePage,
    TeacherlistPage,
    TeacherDetailPage,
    PickTeacher,
    LesofflinePage,
    ProfilePage,
    SchedulePage,
    CanvasPage,
    CallModal,
    EvideoPage,
    EvideoListPage,
    EvideoDetailPage,
    TransactionsPage,
    DetailTransaction,
    EnotesPage,
    EnotesListPage,
    EnotesDetailPage,
    ReadEnotesPage,
    DepositPage,
    DepositDoPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ApiProvider,
    AuthProvider,
    HttpModule,
    HttpClientModule,
    LoadingProvider,
    DatePicker,
    CallProvider,
    VideoProvider,
    AudioProvider,
    TriggerProvider,
    StreamingMedia,
    OneSignal,
    Stripe,
    LocationTrackerProvider,
    Geolocation,
    BackgroundGeolocation,
    AndroidPermissions 
  ]
})
export class AppModule {}

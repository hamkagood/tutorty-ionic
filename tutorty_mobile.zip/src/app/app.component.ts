import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, MenuController, Events } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { ProfilePage } from '../pages/profile/profile'
import { TransactionsPage } from './../pages/transactions/transactions';
import { WelcomePage } from '../pages/auth/auth';
import { Socket } from 'ng-socket-io';
import { CallProvider } from '../providers/call/call';
import { TriggerProvider } from '../providers/trigger/trigger';
import { OneSignal } from '@ionic-native/onesignal';
import { ApiProvider } from './../providers/api/api';
import { DepositPage } from './../pages/deposit/deposit';
import { LocationTrackerProvider } from '../providers/location-tracker/location-tracker';
import { AndroidPermissions } from '@ionic-native/android-permissions';

declare var cordova:any;
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any;
	isInCall = false
  pages: Array<{icon: any, title: string, component: any}>;
  name: any;
  email: any;
  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen, public menu: MenuController, public events: Events,
  private socket: Socket, private callProvider: CallProvider, callModalTrigger: TriggerProvider, private oneSignal: OneSignal, private api: ApiProvider, public locationtracker: LocationTrackerProvider,
  private androidPermissions: AndroidPermissions
  ) {
    this.initializeApp();
    this.socket.connect();

    this.name = localStorage.getItem('name');
    this.email = localStorage.getItem('email');
    // used for an example of ngFor and navigation
    this.pages = [
      {
        icon: 'home',
        title: 'Home',
        component: HomePage
      },
      {
        icon: 'list-box',
        title: 'History',
        component: TransactionsPage
      },
      {
        icon: 'md-cash',
        title: 'Deposit',
        component: DepositPage
      },
      {
        icon: 'contact',
        title: 'Profile',
        component: ProfilePage
      },
      {
        icon: 'log-out',
        title: 'Logout',
        component: WelcomePage
      }
    ];
		this.events.subscribe('call.status.isincall', status => {
			console.log('call status changed to ', status);
			this.isInCall = status;
		});
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      console.log('request permission');
      // this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.CAMERA).then(
      //   result => console.log('Has permission?',result.hasPermission),
      //   err => this.androidPermissions.requestPermissions([this.androidPermissions.PERMISSION.CAMERA])
      // );

      var check = localStorage.getItem("login");
      if (check == "true") {
        this.locationtracker.startTracking();
        this.events.subscribe('profile', (name, email) =>{
          this.name = name;
          this.email = email;
        });
        if (this.platform.is('cordova')) {
          this.oneSignal.startInit('85ef7c05-4496-4fcf-ae67-0d1de360b639', '114878208761');

          this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.Notification);

          this.oneSignal.handleNotificationReceived().subscribe(() => {
            // do something when notification is received
          });

          this.oneSignal.handleNotificationOpened().subscribe((data) => {
            let payload = data;
            // this.redirectToPage(payload);
          });
          this.oneSignal.endInit();
          this.oneSignal.getIds().then((id) => {
            console.log(id)
            this.api.updatePlayerIdOnesignal(id.userId).subscribe(res => {
              console.log(res);
            })
          })
          console.log(this.oneSignal);
        }
        this.rootPage = HomePage;
      } else {
        this.rootPage = WelcomePage;
      }
    });
  }
  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}

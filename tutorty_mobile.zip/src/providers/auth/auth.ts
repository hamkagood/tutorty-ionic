import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable }   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { config } from '../../app/config'
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/x-www-form-urlencoded'
  })
};
@Injectable()
export class AuthProvider {
  constructor(public http: HttpClient) {
    console.log('Hello AuthProvider Provider');
  }
  login(email,password) {
    var body = 'email=' + email + '&password=' + password;
    return this.http.post(config.API_ENDPOINT + '/authentication/login', body, httpOptions);
  }
  register(data) {
    var body = 'email=' + data.email + '&password=' + data.password + '&first_name=' + data.first_name + '&last_name=' + data.last_name + '&role=' + data.role
    return this.http.post(config.API_ENDPOINT + '/authentication/register', body, httpOptions);
  }
}

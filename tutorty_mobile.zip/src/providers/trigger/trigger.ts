import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ModalController, Events } from 'ionic-angular';
import { CallModal } from '../../pages/chat/chat';
@Injectable()
export class TriggerProvider {
	modal = null

	constructor(private events: Events, private modalCtrl: ModalController) {
		let self = this;
		this.events.subscribe('call.trigger.show', data => {
			console.debug('SHOWING CALL FROM EVENT')
			self.call();
    });
    console.log('SHOWING CALL FROM EVENT')
	}
	public call() {
		this.modal = this.modalCtrl.create(CallModal);
		this.modal.present();
	}
}

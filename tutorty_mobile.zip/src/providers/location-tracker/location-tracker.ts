import { Injectable, NgZone } from '@angular/core';
import { BackgroundGeolocation } from '@ionic-native/background-geolocation';
import { Geolocation, Geoposition } from '@ionic-native/geolocation';
import { ApiProvider } from '../api/api';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
@Injectable()
export class LocationTrackerProvider {
    public watch: any;
    public lat: number = 0;
    public lng: number = 0;
    constructor(public api: ApiProvider, private geolocation: Geolocation, private backgroundGeolocation: BackgroundGeolocation, public zone: NgZone) {
        console.log('Hello LocationTrackerProvider Provider');
    }
    startTracking() {
        let config = {
            desiredAccuracy: 0,
            stationaryRadius: 20,
            distanceFilter: 10,
            debug: false,
            interval: 300,
            notificationTitle: "Tutorty",
            notificationText: "Getting Location...."
        };

        this.backgroundGeolocation.configure(config).subscribe((location) => {
            console.log('BackgroundGeolocation:  ' + location.latitude + ',' + location.longitude);
            var data = {
                "latitude": location.latitude,
                "longitude": location.longitude
            }
            this.api.updateProfileLocation(location.longitude, location.latitude).subscribe(res => {
              console.log(res);
            })
            // let headers = new Headers({
            // //     'Content-Type': 'application/json',
            // //     'Authorization': localStorage.getItem("token")
            // // });
            // // let options = new RequestOptions({
            // //     headers: headers
            // // });
            // // this.http.post(AppSettings.API_ENDPOINT + '/geolocate', data, options).map(res => res.json())
            // //     .subscribe(
            // //         data => {
            // //             console.log("sukses update lokasi")
            // //         },
            // //         err => {
            // //             console.log(err);
            // //         }
            // //     );

            this.zone.run(() => {
                this.lat = location.latitude;
                this.lng = location.longitude;
            });

        }, (err) => {

        });
        this.backgroundGeolocation.start();


        let options = {
            frequency: 3000,
            enableHighAccuracy: true
        };

        this.watch = this.geolocation.watchPosition(options).filter((p: any) => p.code === undefined).subscribe((position: Geoposition) => {

            console.log(position);
            this.zone.run(() => {
                this.lat = position.coords.latitude;
                this.lng = position.coords.longitude;
            });

        });
    }

    stopTracking() {
        this.backgroundGeolocation.finish();
        this.watch.unsubscribe();

    }
}

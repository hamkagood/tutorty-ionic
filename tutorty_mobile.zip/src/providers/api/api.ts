import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { config } from '../../app/config'

@Injectable()
export class ApiProvider {

  constructor(public http: HttpClient) {
    console.log('Hello ApiProvider Provider');
  }
  getProfile(id) {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/profile/?id=' + id, httpOptions);
  }
  getLevel() {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/level', httpOptions);
  }
  getClass(level_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/class?level_id=' + level_id, httpOptions);
  }
  getCourse(class_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/course?class_id=' + class_id, httpOptions);
  }
  getBalance() {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/balanceCoin?user_id=' + localStorage.getItem('id'), httpOptions);
  }
  getTeacherbyCourse(course_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/teacher?course_id=' + course_id, httpOptions);
  }
  getTeacherbyCourseOffline(course_id, lat, lng) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/teacheroffline?course_id=' + course_id + '&lat=' + lat + '&lng=' + lng + '&user_id=' + localStorage.getItem('id'), httpOptions);
  }
  getTeacherDetail(teacher_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/teacherDetail?teacher_id=' + teacher_id, httpOptions);
  }
  postTransaction(price, duration, teacher_id, modul) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'price=' + price + '&duration=' + duration + '&teacher_id=' + teacher_id + '&student_id=' + localStorage.getItem('id') + '&module=' + modul;
    return this.http.post(config.API_ENDPOINT + '/v1/transaction', body, httpOptions);
  }
  postTransactionOffline(modul, data) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var price = data.duration.split('~');
    let body = 'module=' + modul +'&student_id=' + localStorage.getItem('id') +
               '&teacher_id=' + data.teacher_id + '&price=' + price[1] + '&duration=' + price[0] +
               '&time=' + data.time + '&address=' + data.address + '&phone=' + data.phone +
               '&remarks=' + data.remarks;
    return this.http.post(config.API_ENDPOINT + '/v1/transactionOffline', body, httpOptions);
  }
  getMyAccount() {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/profile?user_id=' + localStorage.getItem('id'), httpOptions);
  }
  updateProfile(first_name, last_name, phone, dob, gender) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'first_name=' + first_name + '&last_name=' + last_name + '&phone=' + phone + '&dob=' + dob + '&gender=' + gender + '&user_id=' + localStorage.getItem('id');
    return this.http.post(config.API_ENDPOINT + '/v1/profile', body, httpOptions);
  }
  updateContact(province_id, city_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'province_id=' + province_id + '&city_id=' + city_id + '&user_id=' + localStorage.getItem('id');
    return this.http.post(config.API_ENDPOINT + '/v1/location', body, httpOptions);
  }
  getProvinces() {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/province', httpOptions);
  }
  getDistrict(id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/districts/?province_id=' + id , httpOptions);
  }
  getScheduleTeacher(id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/teacherschedule/?teacher_id=' + id , httpOptions);
  }
  getEvideoByCourse(course_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/evideo?course_id=' + course_id, httpOptions);
  }
  getDetailEvideo(code)
  {
     var httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/x-www-form-urlencoded',
          'X-API-KEY': localStorage.getItem("key")
        })
      };
      return this.http.get(config.API_ENDPOINT + '/v1/detailEvideo/?code=' + code + '&user_id=' + localStorage.getItem('id'), httpOptions);
  }
  postTransactionEvideo(price, teacher_id, evideo_id, modul) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'price=' + price + '&duration=0' + '&teacher_id=' + teacher_id + '&student_id=' + localStorage.getItem('id') + '&evideo_id=' + evideo_id + '&module=' + modul;
    return this.http.post(config.API_ENDPOINT + '/v1/transactionEvideo', body, httpOptions);
  }
  getTransactions() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/studenttransactions/?student_id=' + localStorage.getItem('id'), httpOptions);
  }
  getTransaction(id) {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/transaction/?id=' + id, httpOptions);
  }
  updatePlayerIdOnesignal(player_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'onesignal_id=' + player_id + '&user_id=' + localStorage.getItem('id');
    return this.http.post(config.API_ENDPOINT + '/v1/profileonesignal', body, httpOptions);
  }
  getEnotesByCourse(course_id) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    return this.http.get(config.API_ENDPOINT + '/v1/enotes?course_id=' + course_id, httpOptions);
  }
  getDetailEnotes(code)
  {
     var httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/x-www-form-urlencoded',
          'X-API-KEY': localStorage.getItem("key")
        })
      };
      return this.http.get(config.API_ENDPOINT + '/v1/detailEnotes/?code=' + code + '&user_id=' + localStorage.getItem('id'), httpOptions);
  }
  postTransactionEnotes(price, teacher_id, enotes_id, modul) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'price=' + price + '&duration=0' + '&teacher_id=' + teacher_id + '&student_id=' + localStorage.getItem('id') + '&enotes_id=' + enotes_id + '&module=' + modul;
    return this.http.post(config.API_ENDPOINT + '/v1/transactionEnotes', body, httpOptions);
  }
  getDetailReadEnotes(id)
  {
     var httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/x-www-form-urlencoded',
          'X-API-KEY': localStorage.getItem("key")
        })
      };
      return this.http.get(config.API_ENDPOINT + '/v1/readdetailEnotes/?id=' + id, httpOptions);
  }
  postDeposit(token, amount, card) {

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'X-API-KEY': localStorage.getItem("key")
      })
    };
    var body = 'stripeToken=' + token + '&amount=' + amount + '&secret=' + card + '&user_id=' + localStorage.getItem('id');
    return this.http.post(config.API_ENDPOINT + '/v1/charge', body, httpOptions);
  }
  getDepositMember()
  {
     var httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/x-www-form-urlencoded',
          'X-API-KEY': localStorage.getItem("key")
        })
      };
      return this.http.get(config.API_ENDPOINT + '/v1/depositUser/?id=' + localStorage.getItem('id'), httpOptions);
  }
  updateProfileLocation(lng, lat) {
    var httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-API-KEY': localStorage.getItem("key")
        })
    };
    var body = 'user_id=' + localStorage.getItem('id') + '&lng=' + lng + '&lat=' + lat;
    return this.http.post(config.API_ENDPOINT + '/v1/locationProfile', body, httpOptions);
  }
}

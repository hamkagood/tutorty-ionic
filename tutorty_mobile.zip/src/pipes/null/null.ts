import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the NullPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'null',
})
export class NullPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: any, ...args) {
    return (!value) ? 'This Teacher is still shy to write Bio' : value; 
  }
}

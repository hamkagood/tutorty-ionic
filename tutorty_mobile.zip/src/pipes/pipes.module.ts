import { NgModule } from '@angular/core';
import { MathPipe } from './math/math';
import { NullPipe } from './null/null';
@NgModule({
	declarations: [MathPipe,
    NullPipe],
	imports: [],
	exports: [MathPipe,
    NullPipe]
})
export class PipesModule {}
